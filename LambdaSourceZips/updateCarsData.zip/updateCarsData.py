import os
import json
import boto3

dynamodb_client = boto3.client('dynamodb')
ssm_client = boto3.client('ssm')
baseTablePartitionKeyName = 'manufacturer'
baseTableSortKeyName = 'model'

def lambda_handler(event, context):
    
    tableName = ssm_client.get_parameter(Name=os.environ['DYNAMODB_TAB_PARAM_NAME'])['Parameter']['Value']
    
    multiValueQueryStringParameters = event["multiValueQueryStringParameters"]
    print(multiValueQueryStringParameters)
    if multiValueQueryStringParameters == None:
        return {
            'statusCode': 200,
            'body': json.dumps('Nothing to update!')
        }
    
    baseTablePartitionKeyValue = None
    baseTableSortKeyValue = None
    updateExpressionString = None
    uniqueId = None
    expressionAttributeValues = {}
    
    for key in multiValueQueryStringParameters:
        if key == baseTablePartitionKeyName:
            baseTablePartitionKeyValue = multiValueQueryStringParameters[key][0]
        elif key == baseTableSortKeyName:
            baseTableSortKeyValue = multiValueQueryStringParameters[key][0]
        elif key == 'ID':
            uniqueId = multiValueQueryStringParameters[key][0]
        else:
            if updateExpressionString == None:
                updateExpressionString = "SET " + key + " = :" + key
            else:
                updateExpressionString += ", " + key + " = :" + key
            expressionAttributeValues[":"+key] = {
                'S':  multiValueQueryStringParameters[key][0]
            }
    if baseTablePartitionKeyValue == None or baseTableSortKeyValue == None or uniqueId == None:
        return {
            'statusCode': 200,
            'body': json.dumps('Primary key could not be derived from the input')
        }
    print("updateExpressionString: ", updateExpressionString)
    print("expressionAttributeValues: ", expressionAttributeValues)
    if updateExpressionString == None:
        return {
            'statusCode': 200,
            'body': json.dumps('Nothing to update')
        }
        
    baseTableSortKeyValue = baseTableSortKeyValue + "_" + uniqueId
    print("baseTableSortKeyValue: ", baseTableSortKeyValue)
    Key={
            baseTablePartitionKeyName: {
                'S': baseTablePartitionKeyValue,
            },
            baseTableSortKeyName: {
                'S': baseTableSortKeyValue,
            },
        }
    
    params = {}
    params['TableName'] = tableName
    params['Key'] = Key
    #ReturnValues='NONE'|'ALL_OLD'|'UPDATED_OLD'|'ALL_NEW'|'UPDATED_NEW',
    params['ReturnConsumedCapacity'] = 'TOTAL'
    params['UpdateExpression'] = updateExpressionString
    #ConditionExpression='string',
    #ExpressionAttributeNames={
        #'string': 'string'
    #},
    params['ExpressionAttributeValues'] = expressionAttributeValues
    #ReturnValuesOnConditionCheckFailure='ALL_OLD'|'NONE'
    print("params: ", params)
    response = dynamodb_client.update_item(
        **params
    )
    
    return {
        'statusCode': 200,
        'body': json.dumps('Updated the data successfully!')
    }
