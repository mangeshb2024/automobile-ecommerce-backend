import os
import json
import boto3

dynamodb_client = boto3.client('dynamodb')
ssm_client = boto3.client('ssm')
s3_client = boto3.client('s3')

baseTablePartitionKeyName = 'manufacturer'
baseTableSortKeyName = 'model'
staticAssetBucketName = ssm_client.get_parameter(Name=os.environ['STATIC_DATA_S3BUCKET_PARAM_NAME'])['Parameter']['Value']

def lambda_handler(event, context):
    
    tableName = ssm_client.get_parameter(Name=os.environ['DYNAMODB_TAB_PARAM_NAME'])['Parameter']['Value']

    multiValueQueryStringParameters = event["multiValueQueryStringParameters"] 
    if multiValueQueryStringParameters == None:
        multiValueQueryStringParamsLen = 0
    else:
        multiValueQueryStringParamsLen = len(multiValueQueryStringParameters)

    lsi_list = ['lsi_bodytype','lsi_vehicletype','lsi_engine','lsi_fuel','lsi_transmission']
    gsi_list = ['gsi_bodytype_model','gsi_bodytype_engine','gsi_bodytype_fuel','gsi_bodytype_transmission',
                'gsi_engine_fuel','gsi_engine_transmission','gsi_fuel_transmission','gsi_transmission']
                #'gsi_model_engine','gsi_model_fuel','gsi_model_transmission'

    partitionKeyName = None
    partitionKeyValue = None
    sortKeyName = None
    sortKeyValue = None
    indexType = None
    indexName = None
    FilterExpression = None
    KeyConditionExpression = None
    ExpressionAttributeValues = {}
    ManualFilter = []

    primaryKeyType = None
    if multiValueQueryStringParamsLen > 0:
        
        singleValueParams = {key: 1 for key in multiValueQueryStringParameters if len(multiValueQueryStringParameters[key]) == 1}
        
        if len(singleValueParams) > 0:
            
            if baseTablePartitionKeyName in singleValueParams:
                
                if baseTableSortKeyName in singleValueParams:
                    partitionKeyName = baseTablePartitionKeyName
                    partitionKeyValue = multiValueQueryStringParameters[partitionKeyName][0]
                    sortKeyName = baseTableSortKeyName
                    sortKeyValue = multiValueQueryStringParameters[sortKeyName][0]
                    indexType = 'BaseTable'
                    indexName = None
                    primaryKeyType = 'Composite'
                else:
                    for key in singleValueParams:
                        if key != baseTablePartitionKeyName and 'lsi'+ "_" +key in lsi_list:
                            partitionKeyName = baseTablePartitionKeyName
                            partitionKeyValue = multiValueQueryStringParameters[baseTablePartitionKeyName][0]
                            sortKeyName = key
                            sortKeyValue = multiValueQueryStringParameters[sortKeyName][0]
                            indexType = 'LSI'
                            indexName = 'lsi'+ "_" +key
                            primaryKeyType = 'Composite'
                            break

            else:
                for key1 in singleValueParams:
                    for key2 in singleValueParams:
                        if key1 != key2 and 'gsi'+ "_" +key1+ "_" +key2 in gsi_list:
                            partitionKeyName = key1
                            partitionKeyValue = multiValueQueryStringParameters[partitionKeyName][0]
                            sortKeyName = key2
                            sortKeyValue = multiValueQueryStringParameters[sortKeyName][0]
                            indexType = 'GSI'
                            indexName = 'gsi'+ "_" +key1+ "_" +key2
                            primaryKeyType = 'Composite'
                            break
                    if primaryKeyType == 'Composite':
                        break

            if primaryKeyType == None:
                if baseTablePartitionKeyName in singleValueParams:
                    partitionKeyName = baseTablePartitionKeyName
                    partitionKeyValue = multiValueQueryStringParameters[partitionKeyName][0]
                    indexType = 'BaseTable'
                    indexName = None
                    primaryKeyType = 'Simple'
                    sortKeyName = baseTableSortKeyName
                else:
                    for key in singleValueParams:
                        for gsi_ind in gsi_list:
                            if gsi_ind.startswith('gsi' + "_" + key):
                                partitionKeyName = key
                                partitionKeyValue = multiValueQueryStringParameters[partitionKeyName][0]
                                indexType = 'GSI'
                                indexName = gsi_ind
                                primaryKeyType = 'Simple'
                                index_split = gsi_ind.split("_")
                                if len(index_split) == 3:
                                    sortKeyName = index_split[2]
                                break
                        if primaryKeyType == 'Simple':
                            break

        if partitionKeyName != None:
            KeyConditionExpression = partitionKeyName + " = :" + partitionKeyName
            ExpressionAttributeValues[":"+partitionKeyName] = {
                    'S': partitionKeyValue
            }
        if sortKeyName != None and primaryKeyType != 'Simple':
            if sortKeyName == baseTableSortKeyName:
                KeyConditionExpression += " and begins_with(" + sortKeyName + ", :" + sortKeyName + ")"
            else:
                KeyConditionExpression += " and " + sortKeyName + " = :" + sortKeyName
            ExpressionAttributeValues[":"+sortKeyName] = {
                    'S': sortKeyValue
            }
        for key in multiValueQueryStringParameters:
            pushKeyToFilter = False
            pushKeyToManual = False
            if indexType == None:
                if key == baseTableSortKeyName:
                    pushKeyToManual = True
                else:
                    pushKeyToFilter = True
            else:
                if primaryKeyType == 'Simple':
                    if key == sortKeyName or key == baseTableSortKeyName:
                        pushKeyToManual = True
                    elif key == partitionKeyName:
                        next
                    else:
                        pushKeyToFilter = True
                elif primaryKeyType == 'Composite':
                    if key not in [partitionKeyName, sortKeyName]:
                        pushKeyToFilter = True
            if pushKeyToFilter:
                if FilterExpression == None:
                    FilterExpression = "contains(:"+key+", "+key+")"
                else:
                    FilterExpression += " and contains(:"+key+", "+key+")"
                ExpressionAttributeValues[":"+key] = {
                    'SS': multiValueQueryStringParameters[key]
                }
            if pushKeyToManual:
                ManualFilter.append(key)

    print("primaryKeyType: ", primaryKeyType)
    print("FilterExpression: ", FilterExpression)
    print("ExpressionAttributeValues: ", ExpressionAttributeValues)
    print("ManualFilter: ", ManualFilter)

    params = {}
    if primaryKeyType == None:
        #scan
        params['TableName'] = tableName
        params['Select'] = 'ALL_ATTRIBUTES'
        params['ReturnConsumedCapacity'] = 'TOTAL'
        if FilterExpression != None:
            params['FilterExpression'] = FilterExpression
        if len(ExpressionAttributeValues) > 0:
            params['ExpressionAttributeValues'] = ExpressionAttributeValues
        print("params: ", params)
        response = dynamodb_client.scan(
            **params
        )
    else:
        #query
        params['TableName'] = tableName
        if indexName != None:
            params['IndexName'] = indexName
        params['Select'] = 'ALL_ATTRIBUTES'
        params['ReturnConsumedCapacity'] = 'TOTAL'
        if FilterExpression != None:
            params['FilterExpression'] = FilterExpression
        if KeyConditionExpression != None:
            params['KeyConditionExpression'] = KeyConditionExpression
        if len(ExpressionAttributeValues) > 0:
            params['ExpressionAttributeValues'] = ExpressionAttributeValues

        response = dynamodb_client.query(
            **params
    )
    
    print("response[Items]: ", response["Items"])
    
    if len(ManualFilter) > 0:
        for key in ManualFilter:
            # To be implemented - filter based on model
            if key == baseTableSortKeyName:
                continue
                #for value in multiValueQueryStringParameters[key]:
                #    print("values: ", value)
            else:
                response["Items"] = [d for d in response["Items"] if d.get(key)["S"] in multiValueQueryStringParameters[key]]

    formattedResponse = enrichResponse(response["Items"])

    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({'count': len(formattedResponse), 'results': formattedResponse})
    }

def enrichResponse(Items):
    response = []
    imageCacheHash = {}
    for item in Items:
        item_temp = {}
        for key in item:
            if key == baseTableSortKeyName:
                car_model, id = item[key]["S"].split("_")
                item_temp[key] = car_model
                item_temp["ID"] = id
                s3ObjLookupKey = item["manufacturer"]["S"]+"/"+car_model
                s3ObjLookupKey = s3ObjLookupKey.replace(" ","-")

                if s3ObjLookupKey in imageCacheHash:
                    for image_name in imageCacheHash[s3ObjLookupKey]:
                        if 'Highlight' in image_name:
                            item_temp['highlight_image'] = image_name
                    item_temp["Images"] = imageCacheHash[s3ObjLookupKey]
                else:
                    resp_s3 = s3_client.list_objects(
                        Bucket=staticAssetBucketName,
                        Prefix=s3ObjLookupKey,
                        MaxKeys=50000
                    )
                    images = []
                    if 'Contents' in resp_s3:
                        if len(resp_s3['Contents']) > 0:
                            for record in resp_s3['Contents']:
                                url = "https://" + staticAssetBucketName + ".s3.amazonaws.com/" + record['Key']
                                if 'Highlight' in url:
                                    item_temp['highlight_image'] = url
                                images.append(url)
                    item_temp["Images"] = images
                    imageCacheHash[s3ObjLookupKey] = images
            else:
                item_temp[key] = item[key]["S"]
        response.append(item_temp)
    return response