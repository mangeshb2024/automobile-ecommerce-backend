import os
import json
import uuid
import boto3
import zipfile

s3_client = boto3.client('s3')
dynamodb_client = boto3.client('dynamodb')
ssm_client = boto3.client('ssm')

def lambda_handler(event, context):
    
    bucket    = event['Records'][0]['s3']['bucket']['name']
    input_file  = event['Records'][0]['s3']['object']['key']
    
    dataTableName = ssm_client.get_parameter(Name=os.environ['DYNAMODB_TAB_PARAM_NAME'])['Parameter']['Value']
    filterTableName = ssm_client.get_parameter(Name=os.environ['DDB_FILTER_TAB_PARAM_NAME'])['Parameter']['Value']
    destinatioBucket = ssm_client.get_parameter(Name=os.environ['STATIC_DATA_S3BUCKET_PARAM_NAME'])['Parameter']['Value']
    
    input_file_extension = (input_file.split(".")[-1]).lower()
    
    csv_file_array = []
    image_file_array = []
    csv_load_response = ''
    isZipArchive = False
    zipArchiveFileName = ''
    
    if input_file_extension == 'zip':
        
        s3_client.download_file(bucket, input_file, '/tmp/' + input_file)
        with zipfile.ZipFile('/tmp/' + input_file, 'r') as zip_ref:
            zip_ref.extractall('/tmp/')
        for filename in os.listdir('/tmp'):
            if filename != input_file:
                filename_extension = (filename.split(".")[-1]).lower()
                if filename_extension == 'csv':
                    csv_file_array.append(filename)
                    print(f"Archive: {input_file}, File: {filename}, Added for csv loading")
                elif filename_extension in ['jpeg', 'jpg', 'png', 'webp']:
                    image_file_array.append(filename)
                    print(f"Archive: {input_file}, File: {filename}, Added for image loading")
                else:
                    print(f"Archive: {input_file}, File: {filename}, Skipped...unsupported extension.")
            
        isZipArchive = True
        zipArchiveFileName = input_file
        
    elif input_file_extension == 'csv':
        
        csv_file_array.append(input_file)
        
    elif input_file_extension in ['jpeg', 'jpg', 'png', 'webp']:
        
        image_file_array.append(input_file)
        
    else:
        
        print("Unsupported file extension.")
        csv_load_response = "Unsupported file extension."
        return {
            'statusCode': 200,
            'body': json.dumps(csv_load_response)
        }
        
    if len(image_file_array) > 0:
        loadImages(bucket, destinatioBucket, image_file_array, isZipArchive)

    if len(csv_file_array) > 0:
        loadAttributes(bucket, csv_file_array, dataTableName, filterTableName, isZipArchive, zipArchiveFileName)
        
    # Delete the input file and tmp files
    if isZipArchive:
        for filename in os.listdir('/tmp'):
            if not os.path.isdir('/tmp/'+filename):
                os.remove("/tmp/"+filename)
            
    del_response = s3_client.delete_object(
        Bucket=bucket,
        Key=input_file,
    )
    print(f"{input_file}: File deleted.")

    return {
        'statusCode': 200,
        'body': json.dumps("Done.")
    }

######################################################
# def loadImages
# Function to load images in the static data S3 bucket
######################################################

def loadImages(source_bucket, destination_bucket, image_file_array, isZipArchive):
    
    static_resp = s3_client.list_objects(
        Bucket=destination_bucket
    )

    existing_images = []
    if 'Contents' in static_resp:
        if len(static_resp['Contents']) > 0:
            existing_images = [image_dict['Key'] for image_dict in static_resp['Contents']]
    
    for image in image_file_array:
    
        destination_file = image.replace("_", "/")
        
        if destination_file not in existing_images:
    
            if isZipArchive:

                s3_client.upload_file("/tmp/" + image, destination_bucket, destination_file)
    
            else:
        
                copy_source = {
                    'Bucket': source_bucket,
                    'Key': image
                }

                s3_client.copy(copy_source, destination_bucket, destination_file)
                
            print(f"{destination_file} uploaded successfully in the static data bucket {destination_bucket}")
                
        else:
            print(f"{destination_file} already present in the static data bucket {destination_bucket}")

        
    
######################################################
# def loadAttributes
# Function to load attributes data in dynamodb tables
######################################################
def loadAttributes(bucket, csv_file_array, tableName, filterTableName, isZipArchive, zipArchiveFileName):
    
    duplicateCheckDictionary = {}
    empty_table = True
    filterDictionary = {}
    filterDictionaryUpdates = {}
    columnHeaders = []
    
    res_filter = dynamodb_client.scan(
        TableName = filterTableName
    )

    for item in res_filter['Items']:
        filterDictionary[item['filterColumn']['S']] = item['filterColumnValues']['SS']

    response = dynamodb_client.scan(
        TableName = tableName,
        Limit=1
    )
        
    if response['Count'] > 0:
        empty_table = False
    
    for csv_file in csv_file_array:
    
        if isZipArchive:
            print(f"{zipArchiveFileName}: {csv_file}: Processing started...")
        else:
            print(f"{csv_file}: Processing started...")
        
        record_items = []
    
        if isZipArchive:
            with open('/tmp/'+csv_file, mode='r') as file:
                record_items = [line.rstrip() for line in file]
        else:
            csv_object = s3_client.get_object(Bucket=bucket, Key=csv_file)
            file_reader = csv_object['Body'].read().decode("utf-8")
            record_items = file_reader.split("\n")

        columnHeaders = record_items[0].split(",")
        totalCounter = 0
        loadCounter = 0
        skipCounter = 0
        
        for record_item in record_items[1:]:
            
            record_present = False
            record_item_attributes = record_item.split(",")
    
            if record_item_attributes[0] == "":
                continue
    
            totalCounter += 1
    
            if not empty_table:
    
                partition_key = record_item_attributes[0]
    
                if partition_key not in duplicateCheckDictionary:
    
                    response = dynamodb_client.query(
                        TableName = tableName,
                        Select='ALL_ATTRIBUTES',
                        ReturnConsumedCapacity='TOTAL',
                        KeyConditionExpression='manufacturer = :v1',
                        ExpressionAttributeValues={
                            ':v1': {
                                'S': partition_key,
                            }
                        }
                    )
                    
                    if len(response['Items']) > 0:
                        
                        twoDArray = []
                        
                        for item in response['Items']:
                            oneDArray = []
                            oneDArray.append(item['manufacturer']['S'])
                            oneDArray.append(item['model']['S'])
                            oneDArray.append(item['vehicletype']['S'])
                            oneDArray.append(item['bodytype']['S'])
                            oneDArray.append(item['engine']['S'])
                            oneDArray.append(item['fuel']['S'])
                            oneDArray.append(item['transmission']['S'])
                            oneDArray.append(item['transmissiontype']['S'])
                            twoDArray.append(oneDArray)
    
                        duplicateCheckDictionary[partition_key] = twoDArray
                
                if partition_key in duplicateCheckDictionary:
                    
                    for dup_record in duplicateCheckDictionary[partition_key]:
                        
                        if (  dup_record[0] == record_item_attributes[0] and
                              dup_record[1].startswith(record_item_attributes[1]) and
                              dup_record[2] == record_item_attributes[2] and
                              dup_record[3] == record_item_attributes[3] and
                              dup_record[4] == record_item_attributes[4] and
                              dup_record[5] == record_item_attributes[5] and
                              dup_record[6] == record_item_attributes[6] and
                              dup_record[7] == record_item_attributes[7]
                           ):
                            record_present = True
                            break
        
            if record_present:
                if isZipArchive:
                    print(f"{zipArchiveFileName}:{csv_file}: Skipping following record as it is already present in the table")
                    print(f"{zipArchiveFileName}:{csv_file}: {record_item}")
                else:
                    print(f"{csv_file}: Skipping following record as it is already present in the table")
                    print(f"{csv_file}: {record_item}")
                skipCounter += 1
                # If record is already present, 
                # that means the filter must also be present already. 
                # So no need to update it.
            else:
                response = dynamodb_client.put_item(
                    TableName=tableName,
                    Item={
                            'manufacturer' : {
                                'S': record_item_attributes[0]
                            },
                            'model' : {
                                'S': record_item_attributes[1] + "_" + str(uuid.uuid4())
                            },
                            'vehicletype' : {
                                'S': record_item_attributes[2]
                            },
                            'bodytype' : {
                                'S': record_item_attributes[3]
                            },
                            'engine' : {
                                'S': record_item_attributes[4]
                            },
                            'fuel' : {
                                'S': record_item_attributes[5]
                            },
                            'transmission' : {
                                'S': record_item_attributes[6]
                            },
                            'transmissiontype' : {
                                'S': record_item_attributes[7]
                            },
                    }
                )
                
                loadCounter += 1
                
                if isZipArchive:
                    print(f"{zipArchiveFileName}:{csv_file}: Following record inserted")
                    print(f"{zipArchiveFileName}:{csv_file}: {record_item_attributes}")
                else:
                    print(f"{csv_file}: Following record inserted")
                    print(f"{csv_file}: {record_item_attributes}")
                    
                # Update the filter if there is any new.
                for index, attribute in enumerate(record_item_attributes):
                    update_needed = False
                    if columnHeaders[index] not in filterDictionary:
                        filterDictionary[columnHeaders[index]] = [attribute]
                        update_needed = True
                    else:
                        if attribute not in filterDictionary[columnHeaders[index]]:
                            filterDictionary[columnHeaders[index]].append(attribute)
                            update_needed = True
                    if update_needed:
                        filterDictionaryUpdates[columnHeaders[index]] = filterDictionary[columnHeaders[index]]
    
        if len(filterDictionaryUpdates) > 0:
            for updatedFilter in filterDictionaryUpdates:
                response_put = dynamodb_client.put_item(
                    Item={
                        'filterColumn': {
                            'S': updatedFilter,
                        },
                        'filterColumnValues': {
                            'SS': filterDictionaryUpdates[updatedFilter],
                        }
                    },
                    ReturnConsumedCapacity='TOTAL',
                    TableName=filterTableName,
                )
                filterDictionary[updatedFilter] = filterDictionaryUpdates[updatedFilter]

        if isZipArchive:
            print(f"{zipArchiveFileName}:{csv_file}: Total = {totalCounter}, Loaded = {loadCounter}, Skipped = {skipCounter}")
            print(f"{zipArchiveFileName}:{csv_file}: Processing completed.")
        else:
            print(f"{csv_file}: Total = {totalCounter}, Loaded = {loadCounter}, Skipped = {skipCounter}")
            print(f"{csv_file}: Processing completed.")
