import os
import json
import boto3
dynamodb_client = boto3.client('dynamodb')
ssm_client = boto3.client('ssm')


def lambda_handler(event, context):

    filterTableName = ssm_client.get_parameter(
        Name=os.environ['DDB_FILTER_TAB_PARAM_NAME'])['Parameter']['Value']
    filterList = []

    response = dynamodb_client.scan(
        TableName=filterTableName
    )

    for item in response['Items']:
        filterList.append(
            { "filterName": item['filterColumn']['S'],
              "filterValues": [val for val in item['filterColumnValues']['SS'] if val != 'NA']
            }
        )

    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({'count': len(filterList), 'results': filterList})
    }
